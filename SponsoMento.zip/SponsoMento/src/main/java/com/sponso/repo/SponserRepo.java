package com.sponso.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sponso.Pojo.Sponser;

@Repository
public interface SponserRepo extends CrudRepository<Sponser, String>{

}
