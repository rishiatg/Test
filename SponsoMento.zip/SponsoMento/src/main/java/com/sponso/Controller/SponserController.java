package com.sponso.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sponso.Pojo.Sponser;
import com.sponso.Service.SponserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@RestController
@EnableSwagger2
@Api(value="sponser")
public class SponserController {

	@Autowired
	public SponserService sponservice;
	
	@SuppressWarnings({ "rawtypes" })
	@CrossOrigin
	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Saving Sponser", notes = "", response = Sponser.class)
    @ApiResponses(value = { @ApiResponse(code = 201, message = "valid user"),
    @ApiResponse(code = 404, message = "un-authorized user") })
	@ResponseBody
	public ResponseEntity saveSponser(@RequestBody Sponser sponser ){
		
		if(sponservice.save(sponser)=="success") 
		return ResponseEntity.status(201).body("{\"success\":\"Data Saved\"}");
		else
			return ResponseEntity.status(400).body("{\"error\":\"Data not Saved\"}");
	}
	
	@SuppressWarnings({ "rawtypes" })
	@CrossOrigin
	@RequestMapping(value = "/get", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Getting Sponser", notes = "")
    @ApiResponses(value = { @ApiResponse(code = 201, message = "valid user"),
    @ApiResponse(code = 404, message = "un-authorized user") })
	@ResponseBody
	public ResponseEntity getSponser(){
	
		List<Sponser> list = sponservice.getall(); 
		if(!list.isEmpty()) 
		return ResponseEntity.status(201).body(list);
		else
			return ResponseEntity.status(400).body("{\"error\":\"No Data Found\"}");
	}
	
}
