package com.sponso.Service;

import java.util.List;

import com.sponso.Pojo.Sponser;

public interface SponserService {

	public String save(Sponser s);
	
	public List<Sponser> getall();
	
}
